﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("SuperSocket.WebSocket")]
[assembly: AssemblyDescription("SuperSocket.WebSocket")]
[assembly: ComVisible(false)]
[assembly: Guid("0b046c54-9dc3-419c-afd2-4ef7671ff935")]